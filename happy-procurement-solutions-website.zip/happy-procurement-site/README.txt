HAPPY PROCUREMENT SOLUTIONS WEBSITE

FILES
- index.html: website content and structure
- styles.css: responsive styling
- script.js: mobile navigation, FAQ interactions and current year
- assets/hps-logo.jpg: your supplied HPS logo

PUBLISH WITH NETLIFY
1. Extract the ZIP file on your computer or phone.
2. Open https://app.netlify.com/drop in your browser and sign in or create an account.
3. Drag the extracted folder (happy-procurement-site) into the Netlify Drop area. On mobile, use Netlify's deploy flow if drag-and-drop is unavailable.
4. Netlify will publish the website and provide a live URL ending in netlify.app.
5. You can change the site name in Netlify site settings.

CONTACT FORM
The enquiry form is configured for Netlify Forms. After the first deployment, open the site's Forms area in Netlify and confirm form detection is enabled. Submit a test enquiry to verify that form submissions appear in the Netlify dashboard. Configure email notifications in Netlify if you want form enquiries forwarded to an inbox.

BEFORE GOING LIVE
- Check both email addresses and the UK phone/WhatsApp number are correct.
- The site intentionally does not contain invented client testimonials, success statistics, or live tender listings.
- This is a static website; it does not include a live tender database, user accounts, or online payment system.
